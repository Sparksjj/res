searchModule.controller('searchController', ['$scope', "getRequest", "$routeParams", "categoryHelper", "$location", "localStorage", '$rootScope',
function($scope, getRequest, $routeParams, categoryHelper, $location, localStorage, $rootScope){

    $scope.searchData = [];
    $scope.orderSelect;
    $scope.paginationPages;
    $scope.params = $location.search();
    $scope.where = $location.search().where;

    if ($scope.params.where == "all") {
	    $scope.toggle = "products";    	
    }else{
    	$scope.toggle = $scope.params.where;
    }

	/*chenge paginction on button or form*/
	$scope.chengePath = function(n){
		var curentSearch = $location.search()
		curentSearch.page = n
		$location.search(curentSearch)
	}

	$scope.getSortSearch = function(){
		var reuestData = {};
		var serchParams = $location.search();

		if (serchParams.page) {
        	reuestData.page = 'page='+serchParams.page+ "&";
      	}else {
      		reuestData.page = "";
      	};

		if (serchParams.order) {
			$scope.orderSelect=serchParams.order;
			reuestData.order = 'order='+serchParams.order+'&'
		}else{
			reuestData.order ="";
		}

		getRequest.getSerchData($scope.params.key, $scope.params.where).then(function(res){
			$scope.searchData = res.data;
			//$scope.paginationPages = categoryHelper.getPaginationPages($scope.searchData.current_page, $scope.searchData.last_page, 5);
		})
	}
	$scope.getSortSearch();

	$scope.findImage = function(obj, sort){
			return categoryHelper.findImage(obj, sort);
	}

	$scope.changeOrder = function(orderSelect){
		var ss = $location.search()
			switch(orderSelect){
				case 'title:asc':
					ss.order = "title:asc"
					$location.search(ss)
				break;
				case 'title:desc':
					ss.order = "title:desc"
					$location.search(ss)
				break;
				case 'price:asc':
					ss.order = "price:asc"
					$location.search(ss)
				break;
				case 'price:desc':
					ss.order = "price:desc"
					$location.search(ss)
				break;
				default:
					ss.order = ""
					$location.search(ss)
				break;
			}

			$scope.getSortSearch();
	}

	$scope.chengeDisplayMode = function(chengeIt){
		if(chengeIt){
			localStorage.addItem("DisplayMode", chengeIt)
		}else{

			var item = localStorage.getItem("DisplayMode")
			switch(item){
				case '#list-view-small':
					localStorage.addItem("DisplayMode", "#list-view-small");
				break;
				default:
					localStorage.addItem("DisplayMode", "#grid");
					item = "#grid"
				break;
			}
			$('a.nav-link[href="'+item+'"]').trigger('click')
		}
	}
	$scope.chengeDisplayMode();


    $scope.chengeSearchToggle = function(str){
        $scope.toggle = str;	
    }
	$rootScope.$emit('addBodyClass', {className: "page home page-template-default"})
}]);