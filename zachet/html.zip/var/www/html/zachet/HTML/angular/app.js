var app = angular.module("zachet", [
  'ngRoute', 
  "localStorageModule", 
  "localizationModule" , 
  "productModule", 
  "categoriesModule", 
  "searchModule", 
  "staticPageModule"])

  .config(["$routeProvider", "$locationProvider",  function($routeProvider, $locationProvider) {
     // $locationProvider.html5Mode(true);
      $routeProvider
          .when('/', {
              templateUrl: 'views/test.html',
              controller: 'appCtrl',
          })
          .when('/home', {
              templateUrl: 'views/home.html',
              controller: 'appCtrl',
          })
          .when('/category/:catId', {
              templateUrl: 'views/category.html',
              controller: 'categoriesController',
          })
          .when('/category/:catId/product/:prodId', {
              templateUrl: 'views/product.html',
              controller: 'productController',

          })
          .when('/search', {
              templateUrl: 'views/search.html',
              controller: 'searchController',
          })
          .when('/resource/:resId', {
              templateUrl: 'views/resource.html',
              controller: 'staticPageController',
          })
          .otherwise({ 
            templateUrl: 'views/404.html',
            controller: 'appCtrl',
          });
  }])

  .controller('appCtrl', ['$scope', "$rootScope", "localStorage", "localization", "$location", "$http", "getRequest", '$routeParams',
    function($scope, $rootScope, localStorage, localization, $location, $http, getRequest, $routeParams) {

    //console.log($location.url())
    $scope.staticTranslate = [];
    $scope.staticTranslate = 'single-product';
    $scope.navigation = [];
    $scope.bodyClass = "page home page-template-default";
    $scope.menus = [];
    $scope.searchDestination = "all";

    $scope.ids ={
      catId: $routeParams.catId,
    }
    
    getRequest.getCategories().then(function(response) {
      $scope.navigation = response.data;
      $rootScope.$emit("getNavigation");
    }, function(response) {
      //do smc
    });    
    getRequest.getMenus().then(function(response) {
      $scope.menus = response.data;
      /*console.log($scope.menus)*/
    }, function(response) {
      //do smc
    });

    if (localStorage.hasItem("local")) {
      $scope.staticTranslate = localization.getLocal(localStorage.getItem("local"));
      $scope.loc = localStorage.getItem("local");
    }else{
      $scope.loc = "en";
    }


    $scope.changeLanguage = function($event){
      var lan = $event.srcElement.innerText;
      $scope.staticTranslate = localization.getLocal(lan);
      localStorage.addItem('local', lan);
    }

    $scope.chekLang = function(lang){
      if (lang == $scope.loc) {
        return "current-lan";
      }
    }

    $scope.showCategories= function($event){
      var target = $($event.target)
      target.parents('#menu-vertical-menu').find('div.navigation-info').css('display', "none")
      target.parents("li.menu-item-has-children").find("div.navigation-info").css("display", 'block');
    }
    $scope.hideCategories= function(){      
      $("div.navigation-info").css("display", 'none');
    }


    $rootScope.$on("chengeLang", function(e, data){
      $scope.loc = data.loc;
    })

    $rootScope.$on("addBodyClass", function(e, data){
      $scope.bodyClass = data.className;
    });

    $scope.sendSearchForm = function(key, destination){

      destination = destination || "all";
      $location.url('/search?where='+destination+'&key='+key)
    }
    
}])

  .directive('supportingPath', function() { 
    return { 

      restrict: 'E', 
      scope: true, 
      templateUrl: '../app/views/template/supportingPath.html',
      link: function($scope){
        
      }

    }; 
  })

  .factory('getRequest', ['$http', function($http){
 var domen = "http://192.168.10.208"

    var getCategories = function(){
      return $http({
        method: 'GET',
        url: domen + '/api/v1/categories?access_token=OUtqrIR0COFDJ2RsMlfK22ceNBpJOd2gTMR7zqF8',
        data: {"access_token": "OUtqrIR0COFDJ2RsMlfK22ceNBpJOd2gTMR7zqF8"},
      });
    };

    var getCategory = function(id, search){
      return $http({
        method: 'GET',
        url: domen + '/api/v1/categories/'+id+'?'+search.page+search.order+'access_token=OUtqrIR0COFDJ2RsMlfK22ceNBpJOd2gTMR7zqF8',
        data: {"access_token": "OUtqrIR0COFDJ2RsMlfK22ceNBpJOd2gTMR7zqF8"},
      });
    };

    var getProduct = function(id){
      return $http({
        method: 'GET',
        url: domen + '/api/v1/items/'+id+'?access_token=OUtqrIR0COFDJ2RsMlfK22ceNBpJOd2gTMR7zqF8',
        data: {"access_token": "OUtqrIR0COFDJ2RsMlfK22ceNBpJOd2gTMR7zqF8"},
      });
    };

    var getBreadCrumbs = function(id, catOrItem){
      return $http({
        method: 'GET',
        url: domen + '/api/v1/'+catOrItem+'/breadcrumbs/'+id+'?access_token=OUtqrIR0COFDJ2RsMlfK22ceNBpJOd2gTMR7zqF8',
        data: {"access_token": "OUtqrIR0COFDJ2RsMlfK22ceNBpJOd2gTMR7zqF8"},
      });
    };
    var getMenus = function(){
      return $http({
        method: 'GET',
        url: domen + '/api/v1/menus?access_token=OUtqrIR0COFDJ2RsMlfK22ceNBpJOd2gTMR7zqF8',
        data: {"access_token": "OUtqrIR0COFDJ2RsMlfK22ceNBpJOd2gTMR7zqF8"},
      });
    };

    var getSerchData = function(key, where){
      var path = ""
      switch(where){
        case "products":
          path = 'item='+key;
        break;
        case "news":
          path = 'news'+key;
        break;
        case "pages":
          path = 'pages'+key;
        break;
        default:
          path = 'item='+key+'&news='+key+'&page='+key;
        break;
      }
      return $http({
        method: 'GET',
        url: domen + '/api/v1/search?'+path+'&access_token=OUtqrIR0COFDJ2RsMlfK22ceNBpJOd2gTMR7zqF8',
        data: {"access_token": "OUtqrIR0COFDJ2RsMlfK22ceNBpJOd2gTMR7zqF8"},
      });
    };

    var getResource = function(id){
      return $http({
        method: 'GET',
        url: domen + '/api/v1/pages/'+id+'?access_token=OUtqrIR0COFDJ2RsMlfK22ceNBpJOd2gTMR7zqF8',
        data: {"access_token": "OUtqrIR0COFDJ2RsMlfK22ceNBpJOd2gTMR7zqF8"},
      });
    };

    return{
      getCategories: getCategories,
      getCategory: getCategory,
      getProduct: getProduct,
      getBreadCrumbs: getBreadCrumbs,
      getMenus: getMenus,
      getSerchData: getSerchData,
      getResource: getResource
    }
  }])