productModule.controller('productController', ['$scope', '$rootScope', 'productsHistory', "$routeParams", "categoryHelper", "getRequest",
function($scope, $rootScope, productsHistory, $routeParams, categoryHelper, getRequest){
	$scope.productsHistory = productsHistory.getHistory();
	$scope.pathis = [];
	$scope.ids ={
      catId: $routeParams.catId,
      prodId: $routeParams.prodId,
    }

    $scope.product = {};

    getRequest.getBreadCrumbs($routeParams.catId, "categories").then(function(res){
		res.data.forEach(function(el){
			$scope.pathis.push(el)
		})
	})
	/*find navigation name if reload page*/
	$rootScope.$on('getNavigation', function(){
		$scope.categoryName = categoryHelper.findCategoryName($scope.navigation, $routeParams.catId);
		//$scope.findCategoryName($scope.navigation, $routeParams.catId);
	});
	/*find navigation name*/
	$scope.categoryName = categoryHelper.findCategoryName($scope.navigation, $routeParams.catId);
	//$scope.findCategoryName();

	getRequest.getProduct($scope.ids.prodId).then(function(res){
		$scope.product = res.data;
		//console.log(res.data)
		/*add product in breadcrumbs*/
		$scope.pathis.unshift({id: $routeParams.prodId, name: $scope.product.title})
		/*add product in history from server*/
		productsHistory.addHistory({name: $scope.product.title, image: $scope.findImage(1), preview: $scope.product.preview, id: $scope.product.id, categoryId: $scope.product.category_id})
	})

	/*hide block if no history*/
	$scope.hasHistory = function(){
		return $scope.productsHistory.length
	}

	$scope.findImage = function(sort){
		if (!$.isEmptyObject($scope.product)) {
			return categoryHelper.findImage($scope.product.images, sort);
		}
	}
	
	$rootScope.$emit('addBodyClass', {className: $scope.productsHistory.length ? "": "full-width"})

}]);