var staticPageModule = angular.module("staticPageModule", [])
