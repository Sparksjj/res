var categoriesModule = angular.module("categoriesModule", [])
	.factory('categoryHelper', function(){

	var findCategoryName = function(obj, id){
		var name;
		var rec = function(obj) {
			if (obj.children.length) {
				obj.children.forEach(function(el){
					if (el.id == id) {
						name = el.name;
					}else{
						rec(el);						
					}
				})
				
			}else{
				if (obj.id == id) {
					name = obj.name;
				}
			};
		};

		obj.forEach(function(el){
			rec(el)
		})

		return name || "";
	}

	var findImage = function(images, sort){

		var path = "";
		if(images && images.length){
			images.forEach(function(el){
				if (el.sort == sort) {
					path = el.source;
				}
			})
		}
		if (!path) {
			path = "http://placehold.it/250x232"
		}

		return path;
	}
	var getPaginationPages = function(curentPage, lastPage, maxBut){
		var pages = [{number: curentPage, current: true}];
		var leftShift = lastPage - curentPage >= 2 ? 0 : (Math.floor(maxBut/2) -(lastPage - curentPage))-1;
		var but = maxBut-1;
		var counter = curentPage;
		if (counter != 1) {
			while(counter != 1 && Math.floor(but/2)+leftShift!=pages.length){				
				counter--;
				pages.unshift({'ng-href': "", number: counter, current: false});
			}
		}
		if (curentPage == 1) {
			pages.unshift({'href': curentPage, number: "<", current: false});			
		}else{
			pages.unshift({'href': curentPage-1, number: "<", current: false});			
		}
		
		counter = curentPage
		if (counter != lastPage) {
			while(counter != lastPage && but!=pages.length){				
				counter++;
				pages.push({'href': "", number: counter, current: false});
			}
		}
		if (curentPage == lastPage) {
			pages.push({'href': curentPage, number: ">", current: false})
		}else{
			pages.push({'href': curentPage+1, number: ">", current: false})			
		}

		return pages;
	}

	return{
		findCategoryName: findCategoryName,
		findImage: findImage,
		getPaginationPages: getPaginationPages
	}
})

  .directive('pagination', function() { 
    return { 

      restrict: 'E', 
      scope: true, 
      templateUrl: '../angular/categoriesModule/layouts/pagination.html',
      link: function($scope){
        
      }

    }; 
  })