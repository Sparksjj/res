var searchModule = angular.module("searchModule", [])
