categoriesModule.controller('categoriesController', ['$scope', '$rootScope', "getRequest", "$routeParams", "categoryHelper", "$location", "localStorage",
function($scope, $rootScope, getRequest, $routeParams, categoryHelper, $location, localStorage){
	$scope.ids ={
      catId: $routeParams.catId,
    }
    $scope.products = [];
    $scope.orderSelect= "";
    $scope.paginationPages;

	/*find navigation name if reload page*/
	$rootScope.$on('getNavigation', function(){
		$scope.categoryName = categoryHelper.findCategoryName($scope.navigation, $routeParams.catId);
		//$scope.findCategoryName($scope.navigation, $routeParams.catId);
	});
	/*find navigation name*/
	$scope.categoryName = categoryHelper.findCategoryName($scope.navigation, $routeParams.catId);

	$scope.chengePath = function(n){
		var curentSearch = $location.search()
		curentSearch.page = n
		$location.search(curentSearch)
	}

	getRequest.getBreadCrumbs($routeParams.catId, "categories").then(function(res){
		$scope.pathis = res.data;
	})

	$scope.getSortCategory = function(){
		var reuestData = {};
		var serchParams = $location.search();

		if (serchParams.page) {
        	reuestData.page = 'page='+serchParams.page+ "&";
      	}else {
      		reuestData.page = "";
      	};

		if (serchParams.order) {
			$scope.orderSelect=serchParams.order;
			reuestData.order = 'order='+serchParams.order+'&'
		}else{
			reuestData.order ="";
		}

		getRequest.getCategory($routeParams.catId, reuestData).then(function(res){
			$scope.products = res.data;
			//console.log($scope.products)
			$scope.paginationPages = categoryHelper.getPaginationPages($scope.products.current_page, $scope.products.last_page, 5);
		})
	}
	$scope.getSortCategory();

	$scope.findImage = function(obj, sort){
		return categoryHelper.findImage(obj, sort);
	}

	$scope.changeOrder = function(orderSelect){

		var ss = $location.search()
		
			switch(orderSelect){
				case 'title:asc':
					ss.order = "title:asc";
					$location.search(ss);
				break;
				case 'title:desc':
					ss.order = "title:desc";
					$location.search(ss);
				break;
				case 'price:asc':
					ss.order = "price:asc";
					$location.search(ss);
				break;
				case 'price:desc':
					ss.order = "price:desc";
					$location.search(ss);
				break;
				default:
					ss.order = "";
					$location.search(ss);
				break;
			}

			$scope.getSortCategory();
	}

	$scope.chengeDisplayMode = function(chengeIt){
		if(chengeIt){
			localStorage.addItem("DisplayMode", chengeIt)
		}else{

			var item = localStorage.getItem("DisplayMode")
			switch(item){
				case '#list-view-small':
					localStorage.addItem("DisplayMode", "#list-view-small");
				break;
				default:
					localStorage.addItem("DisplayMode", "#grid");
					item = "#grid"
				break;
			}
			$('a.nav-link[href="'+item+'"]').trigger('click')
		}
	}
	$scope.chengeDisplayMode();
	$rootScope.$emit('addBodyClass', {className: "page home page-template-default"})
}]);