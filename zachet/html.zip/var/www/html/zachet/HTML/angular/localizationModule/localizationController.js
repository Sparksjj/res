localStorageModule.controller('localStorageController', ['$scope', '$rootScope', 
function($scope, $rootScope){

}]);