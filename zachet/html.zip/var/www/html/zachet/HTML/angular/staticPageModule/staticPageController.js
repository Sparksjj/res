staticPageModule.controller('staticPageController', ['$scope', "getRequest", "$location",  '$rootScope', '$routeParams',
function($scope, getRequest, $location, $rootScope, $routeParams){
	$scope.className;
	$scope.resourceData;

	getRequest.getResource($routeParams.resId).then(function(res){
		$scope.resourceData = res.data;	
	}, function(){
		$scope.resourceData = {
			title: "404, страница не найдена",
			error: "Извините, но страница с запрашиваемым ресурсом не найдена.",
		}
	})

	switch($location.url()){
		case '/resource':
		$scope.className = "about full-width page page-template-default";
		break;
		default:
		$scope.className = 'about full-width page page-template-default';
	}
	$rootScope.$emit('addBodyClass', {className: $scope.className})
}]);